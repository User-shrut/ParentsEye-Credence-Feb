export const COLUMNS = () => [
  {
    Header: '',
    accessor: 'select',
    Cell: ({ row }) => (
      <input
        type="checkbox"
        checked={row.original.isSelected}
        onChange={() => row.original.handleRowSelect(row.index)}
      />
    ),
  },
  
  {
    Header: 'Child Name',
    accessor: 'childName',
  },
  
 
  {
    Header: 'class',
    accessor: 'class',
  },
 
  {
    Header: 'rollno',
    accessor: 'rollno',
  },
  {
    Header: 'section',
    accessor: 'section',
  },
  {
    Header: 'School Name',
    accessor: 'schoolName',
  },
  
  {
    Header: 'Child Age',
    accessor: 'childAge',
  },
  {
    Header: 'Phone Number',
    accessor: 'parentPhone', // accessing mapped field
  },
  {
    Header: 'Parent Name',
    accessor: 'parentName', // accessing mapped field
  },
  {
    Header: 'Parent Email',
    accessor: 'parentEmail', // accessing mapped field
  },
//   {
//   Header: 'Phone Number',
//   accessor: 'parentId.phone', // accessing nested field
// },
  // {
  //   Header: 'Password',
  //   accessor: 'password',
  // },
  {
    Header: 'gender',
    accessor: 'gender',
  },
  {
    Header: 'Date of birth',
    accessor: 'dateOfBirth',
  },
];
